<footer>
		<div class="container pageFooter">
			
			<div id="contentCurve"></div>

<p class="text-muted disclaimer text-center ng-binding" ng-bind-html="'loginTermsOfService' | localize:termsAndConditionsUrl:privacyPolicyUrl" style="font-size: 11px">If you register a new account, you agree to Snapchat's <a href="https://snap.com/en-GB/privacy/privacy-policy/" target="_blank">Terms & Conditions</a> and <a href="https://snap.com/en-GB/privacy/privacy-policy/" target="_blank">Privacy Policy</a>.</p>

		</div>
	</footer>

</body>
</html>