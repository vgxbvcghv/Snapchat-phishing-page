# Snapchat-Phishing-Page by 1zu0
The Responsive Phishing Page for Snapchat 2024

1. Change the ending of the file "hwto" to .txt and read...

2. Open data.php with an editor and change the redirected url to an error page

3. Simply upload the files to your server

This is purely for the educational purposes and is not intended to hurt anyone

<img src="https://i.imgur.com/MTT09RJ.png">

<img src="https://i.imgur.com/Xk97qXy.png">
